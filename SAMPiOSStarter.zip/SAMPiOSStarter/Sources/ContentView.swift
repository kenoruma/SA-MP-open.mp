import SwiftUI
import Network

struct ServerInfo: Identifiable {
    let id = UUID()
    let host: String
    let port: UInt16
    var hostname: String
    var gameMode: String
    var language: String
    var players: Int
    var maxPlayers: Int
    var status: String
}

struct ContentView: View {
    @State private var host = "127.0.0.1"
    @State private var port = "7777"
    @State private var results: [ServerInfo] = []
    @State private var isQuerying = false
    @State private var message = "Masukkan IP server dan tekan Query."

    var body: some View {
        NavigationStack {
            Form {
                Section("Server") {
                    TextField("Alamat IPv4 server", text: $host)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    TextField("Port", text: $port)
                        .keyboardType(.numberPad)
                    Button(isQuerying ? "Menghubungi server…" : "Query server") {
                        queryServer()
                    }
                    .disabled(isQuerying || !validInput)
                }

                Section("Hasil") {
                    Text(message).font(.footnote).foregroundStyle(.secondary)
                    ForEach(results) { server in
                        VStack(alignment: .leading, spacing: 5) {
                            Text(server.hostname.isEmpty ? server.host : server.hostname)
                                .font(.headline)
                            Text("\(server.host):\(server.port)")
                                .font(.caption.monospaced())
                            Text("\(server.players)/\(server.maxPlayers) pemain • \(server.gameMode)")
                                .font(.subheadline)
                            if !server.language.isEmpty {
                                Text(server.language).font(.caption).foregroundStyle(.secondary)
                            }
                            Text(server.status).font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 3)
                    }
                }

                Section("Batasan prototipe") {
                    Text("Ini hanya penguji query UDP untuk informasi server. Belum terhubung ke dunia game dan bukan client SA-MP/open.mp lengkap.")
                    Text("Gunakan alamat IPv4 publik atau IP lokal server yang dapat dijangkau dari jaringan iPhone.")
                }
            }
            .navigationTitle("SAMP iOS — Prototype")
        }
    }

    private var validInput: Bool {
        guard IPv4Address(host) != nil, let p = UInt16(port), p > 0 else { return false }
        return true
    }

    private func queryServer() {
        guard let ipv4 = IPv4Address(host),
              let serverPort = UInt16(port), serverPort > 0 else {
            message = "IP IPv4 atau port tidak valid."
            return
        }

        isQuerying = true
        results = []
        message = "Mengirim query informasi server…"

        // SA-MP server query packet: "SAMP" + IPv4 octets + port little-endian + 'i'
        var packet = Array("SAMP".utf8)
        packet += ipv4.rawValue
        packet.append(UInt8(serverPort & 0x00FF))
        packet.append(UInt8((serverPort >> 8) & 0x00FF))
        packet.append(UInt8(ascii: "i"))

        let endpointHost = NWEndpoint.Host(host)
        let endpointPort = NWEndpoint.Port(rawValue: serverPort)!
        let connection = NWConnection(host: endpointHost, port: endpointPort, using: .udp)
        let queue = DispatchQueue(label: "samp.udp.query")

        connection.stateUpdateHandler = { state in
            switch state {
            case .ready:
                connection.send(content: Data(packet), completion: .contentProcessed { error in
                    if let error {
                        DispatchQueue.main.async {
                            self.message = "Gagal mengirim query: \(error.localizedDescription)"
                            self.isQuerying = false
                        }
                        connection.cancel()
                        return
                    }
                    connection.receiveMessage { data, _, _, error in
                        DispatchQueue.main.async {
                            defer {
                                self.isQuerying = false
                                connection.cancel()
                            }
                            if let error {
                                self.message = "Tidak mendapat jawaban: \(error.localizedDescription)"
                                return
                            }
                            guard let data, let parsed = Self.parseInfo(data, host: host, port: serverPort) else {
                                self.message = "Respons tidak dikenali atau server tidak mendukung query info."
                                return
                            }
                            self.results = [parsed]
                            self.message = "Query berhasil. Ini hanya data status server."
                        }
                    }
                })
            case .failed(let error):
                DispatchQueue.main.async {
                    self.message = "Koneksi gagal: \(error.localizedDescription)"
                    self.isQuerying = false
                }
                connection.cancel()
            case .cancelled:
                break
            default:
                break
            }
        }
        connection.start(queue: queue)
    }

    private static func parseInfo(_ data: Data, host: String, port: UInt16) -> ServerInfo? {
        let b = [UInt8](data)
        // Response header: "SAMP" + 4 IPv4 bytes + 2 port bytes + opcode 'i'
        guard b.count >= 11,
              Array(b[0..<4]) == Array("SAMP".utf8),
              b[10] == UInt8(ascii: "i") else { return nil }

        var cursor = 11
        func readUInt8() -> UInt8? {
            guard cursor < b.count else { return nil }
            defer { cursor += 1 }
            return b[cursor]
        }
        func readUInt16LE() -> Int? {
            guard cursor + 1 < b.count else { return nil }
            let value = Int(b[cursor]) | (Int(b[cursor + 1]) << 8)
            cursor += 2
            return value
        }
        func readUInt32LE() -> Int? {
            guard cursor + 3 < b.count else { return nil }
            let value = Int(b[cursor]) |
                (Int(b[cursor + 1]) << 8) |
                (Int(b[cursor + 2]) << 16) |
                (Int(b[cursor + 3]) << 24)
            cursor += 4
            return value
        }
        func readString() -> String? {
            guard let length = readUInt32LE(), length >= 0,
                  cursor + length <= b.count else { return nil }
            let slice = Data(b[cursor..<(cursor + length)])
            cursor += length
            return String(data: slice, encoding: .utf8) ??
                String(data: slice, encoding: .isoLatin1) ?? ""
        }

        guard readUInt8() != nil, // password protected flag
              let players = readUInt16LE(),
              let maxPlayers = readUInt16LE(),
              let hostname = readString(),
              let gameMode = readString(),
              let language = readString() else { return nil }

        return ServerInfo(
            host: host,
            port: port,
            hostname: hostname,
            gameMode: gameMode,
            language: language,
            players: players,
            maxPlayers: maxPlayers,
            status: "UDP query response diterima"
        )
    }
}
