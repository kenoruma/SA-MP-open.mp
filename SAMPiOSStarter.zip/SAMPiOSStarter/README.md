# SAMP iOS Starter (prototype)

Starter SwiftUI untuk menguji query informasi server SA-MP/open.mp melalui UDP.

## Yang bisa dilakukan
- Memasukkan IPv4 dan port server.
- Mengirim paket query informasi `SAMP` dengan opcode `i`.
- Menampilkan nama server, mode, bahasa, dan jumlah pemain jika server menjawab dengan format yang diharapkan.

## Yang belum dilakukan
Ini BUKAN client multiplayer lengkap. Belum ada:
- menjalankan/rendering GTA San Andreas,
- login/handshake pemain,
- protokol gameplay, RPC dan packet sinkronisasi,
- sinkronisasi pemain/kendaraan, chat in-game, atau kontrol sentuh.

open.mp kompatibel dengan banyak client SA-MP, tetapi implementasi client iOS tetap memerlukan porting engine/game dan protokol multiplayer. Jangan menganggap hasil query sebagai bukti bahwa gameplay dapat tersambung.

## Cara mencoba
1. Buat proyek baru **iOS App** di Xcode dengan SwiftUI.
2. Ganti isi `ContentView.swift` dengan file dari `Sources/ContentView.swift`.
3. Gunakan alamat IPv4 server yang memang dapat dijangkau dari jaringan iPhone.
4. Jalankan di simulator/perangkat dari lingkungan build macOS/Xcode.

## Catatan build
Xcode dan code signing iOS memerlukan macOS/toolchain Apple. iPhone saja bisa digunakan untuk mengedit file dan mengelola repo, tetapi tidak menyediakan lingkungan Xcode lokal untuk membangun native IPA secara langsung. Anda memerlukan Mac atau layanan build macOS yang tepercaya.
